package cn.home.wjl.Ajax;
public class User {
	private String userid;
	private String name;
	public String getUserid(){
		return userid;
	}
	public String getName(){
		return name;
	}
	public void setUserid(String userid){
		this.userid=userid;
	}
	public void setName(String name){
		this.name=name;
	}
}
